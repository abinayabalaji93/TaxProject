package com.example.tax.service;

import com.example.tax.model.Department;
import com.example.tax.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;


    public List<Department> getAllDepartments() {
        List<Department> dept=(List<Department>)departmentRepository.findAll();
        return dept;
    }

    public Optional<Department> getDepartment(int id){
        return departmentRepository.findById(id);
    }


    public void addDepartment(Department d) {
        departmentRepository.save(d);
    }

    public void updateDepartment(Department d, int id) {
        if(id == d.getDepartment_ID()) {
            departmentRepository.save(d);
        }
    }

    public void deleteAllDepartment() {

        departmentRepository.deleteAll();
    }








    }

