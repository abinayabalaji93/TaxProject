package com.example.tax.controller;


import com.example.tax.model.Department;
import com.example.tax.service.DepartmentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value="/api/department")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;


    @GetMapping
    public List<Department> getAllDepartment()
    {
      return departmentService.getAllDepartments();

    }

    @GetMapping("/department/{id}")
    public Optional<Department> getDepartment(@PathVariable int id)
    {
        return departmentService.getDepartment(id);
    }

    @PostMapping("/department")
    public void addDepartments(@RequestBody Department department)
    {
        departmentService.addDepartment(department);
    }

    @PutMapping("/department")
 public void updateDepartments(@RequestBody Department d,@PathVariable int id)
    {
        departmentService.updateDepartment(d,id);
    }

@DeleteMapping("/department")
    public void deleteAllDepartments()
{
    departmentService.deleteAllDepartment();
}


}
