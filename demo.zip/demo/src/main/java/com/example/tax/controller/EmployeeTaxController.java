package com.example.tax.controller;


import com.example.tax.model.Employee;
import com.example.tax.service.EmployeeTaxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value="/api/employees")
public class EmployeeTaxController {


    @Autowired
    private EmployeeTaxService employeeTaxService;



    @GetMapping("/employees")
    public List<Employee> getAllEmployee() {
        return employeeTaxService.getAllEmployeeTax();
    }


    @GetMapping("/employees/{id}")
    public Optional<Employee> getEmployee(@PathVariable int id){
        return employeeTaxService.getEmployee(id);
    }


    @PostMapping("/employees")
    public void addEmployeeTax(@RequestBody Employee employee)
    
    {
        employeeTaxService.addEmployeeTax(employee);
    }

    @PutMapping("/employees/{id}")
    public void updateEmployee(@RequestBody Employee e,@PathVariable int id)
    {
        employeeTaxService.updateEmployee(e,id);
    }
@DeleteMapping("/employees")
    public void deleteAllEmployee()
{
    employeeTaxService.deleteAllEmployee();
}


























}
