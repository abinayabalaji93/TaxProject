package com.example.tax.repository;


import com.example.tax.model.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeTaxRepository extends CrudRepository<Employee,Integer> {
}
