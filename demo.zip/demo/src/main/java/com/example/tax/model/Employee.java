package com.example.tax.model;




import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="employees")
public class Employee {




    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="employeeId")
    private int employee_ID;
    @Column(name = "first_name")
    
    private String firstName;
    @Column(name="last_name")
    private String lastName;
    private String email;
    private String gender;
    @Column(name="department_id")
    private String department_ID;

    

    @ManyToOne(cascade = CascadeType.ALL,optional = false)
    @JoinTable(name="departmentId")
    private Department department;
    
    @ManyToOne(cascade = CascadeType.ALL,optional = false)
    @JoinTable(name="employeeId")
    private Salary salary;


}
