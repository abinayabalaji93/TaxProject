package com.example.tax.service;


import com.example.tax.model.Department;
import com.example.tax.model.Employee;
import com.example.tax.repository.EmployeeTaxRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;



@Service
public class EmployeeTaxService {

    @Autowired
    private EmployeeTaxRepository employeeTaxRepository;

    public List<Employee> getAllEmployeeTax() {

        List<Employee> emptax=(List<Employee>)employeeTaxRepository.findAll();
        return emptax;
    }
    public Optional<Employee> getEmployee(int id) {
       return employeeTaxRepository.findById(id);

    }
    public void addEmployeeTax(Employee employee) {
       employeeTaxRepository.save(employee);
    }

    public void updateEmployee(Employee emp, int id){
        if(id == emp.getEmployee_ID()) {
            employeeTaxRepository.save(emp);
        }
    }
    public void deleteAllEmployee() {
        employeeTaxRepository.deleteAll();
    }
}
