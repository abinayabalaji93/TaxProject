package com.example.tax.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="department")
public class Department {

   
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="departmentId")
    private int department_ID;
    private String name;
    
    
    
}



