package com.example.tax.repository;

import com.example.tax.model.Salary;
import org.springframework.data.repository.CrudRepository;

public interface SalaryRepository extends CrudRepository<Salary,Integer> {
}
