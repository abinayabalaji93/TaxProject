package com.example.tax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
